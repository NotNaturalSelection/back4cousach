create function match_gpu_allowed() returns trigger
    language plpgsql
as
$$
begin
    if (new.gpu_id is not null and not (select gpu_allowed from bases where id = new.base_id)) then
        raise exception 'Base in your build does not support gpu but build has one';
    end if;
end
$$;

alter function match_gpu_allowed() owner to sergejmhitaran;

