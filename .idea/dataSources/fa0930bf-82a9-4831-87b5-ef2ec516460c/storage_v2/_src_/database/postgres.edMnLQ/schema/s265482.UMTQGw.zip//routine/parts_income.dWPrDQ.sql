create function parts_income(pn integer) returns integer
    language plpgsql
as
$$
begin
    update s265482.shipments
    set count_left    = count_left + delivery_size,
        delivery_date = delivery_date + delivery_interval
    where delivery_date = current_date and
          part_number = pn;
    return 1;
    end
$$;

alter function parts_income(integer) owner to sergejmhitaran;

