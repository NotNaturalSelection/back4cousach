create function match_display_size() returns trigger
    language plpgsql
as
$$
begin
    if ((select display_size from bases where id = NEW.id) <> (select size_inches from displays where displays.id = NEW.display_id)) then
        raise exception 'Base size differs from display size';
    end if;
    return null;
end
$$;

alter function match_display_size() owner to sergejmhitaran;

